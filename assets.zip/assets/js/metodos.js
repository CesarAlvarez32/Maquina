//-------------------------------------------------------------
function ocultar(){
    document.getElementById('texto').style.display = 'none';
    document.getElementById('a1').style.display = 'block';
}
//-------------------------------------------------------------
function validar(x,x1,x2,x3,x4,x5,x6,x7){
    if(x == "si"){
        if(x1 == ''){
            document.getElementById('a1').style.display = 'none';
            document.getElementById('b2').style.display = 'block';
        }else{
            switch(x1){
                case 'Mascota':
                    document.getElementById('b2').style.display = 'none';
                    document.getElementById('p1').style.display = 'block';
                    break;
                case 'Deportista':
                    if(x6 == ''){
                        document.getElementById('b2').style.display = 'none';
                        document.getElementById('c1').style.display = 'block';
                    }else{
                        switch(x6){
                            case 'Deportista':
                                    if(x7 == ''){
                                        document.getElementById('c1').style.display = 'none';
                                        document.getElementById('d1').style.display = 'block';
                                    }else{
                                        switch(x7){
                                            case 'Barcelona':
                                                    document.getElementById('d1').style.display = 'none';
                                                    document.getElementById('p4').style.display = 'block';
                                                break;
                                            case 'Mexicana':
                                                    document.getElementById('d1').style.display = 'none';
                                                    document.getElementById('p5').style.display = 'block';
                                                break;
                                            case 'Madrid':
                                                    document.getElementById('d1').style.display = 'none';
                                                    document.getElementById('p6').style.display = 'block';
                                                break;
                                        }
                                    }
                                break;
                            case 'Conductor':
                                    document.getElementById('c1').style.display = 'none';
                                    document.getElementById('p3').style.display = 'block';
                                break;
                            case 'Luchador':
                                    document.getElementById('c1').style.display = 'none';
                                    document.getElementById('p2').style.display = 'block';
                                break;
                        }
                    }
                    break;
                case 'Artista':
                        if(x5 == ''){
                            document.getElementById('b2').style.display = 'none';
                            document.getElementById('c2').style.display = 'block';
                        }else{
                            switch(x5){
                                case 'Negro':
                                        if(x7 == ''){
                                            document.getElementById('c2').style.display = 'none';
                                            document.getElementById('d2').style.display = 'block';
                                        }else{
                                            switch(x7){
                                                case 'Queen':
                                                        document.getElementById('d2').style.display = 'none';
                                                        document.getElementById('p8').style.display = 'block';
                                                    break;
                                                case 'Corridos':
                                                        document.getElementById('d2').style.display = 'none';
                                                        document.getElementById('p9').style.display = 'block';
                                                    break;
                                                case 'El sol':
                                                        document.getElementById('d2').style.display = 'none';
                                                        document.getElementById('p10').style.display = 'block';
                                                    break;
                                                case 'Thriller':
                                                        document.getElementById('d2').style.display = 'none';
                                                        document.getElementById('p11').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                                case 'Blanco':
                                        document.getElementById('c2').style.display = 'none';
                                        document.getElementById('p7').style.display = 'block';
                                    break;
                            }
                        }
                    break;
                case 'Entretenimiento':
                        if(x2 == ''){
                            document.getElementById('b2').style.display = 'none';
                            document.getElementById('c3').style.display = 'block';
                        }else{
                            switch(x2){
                                case 'M':
                                        document.getElementById('c3').style.display = 'none';
                                        document.getElementById('p12').style.display = 'block';
                                    break;
                                case 'H':
                                        if(x6 == ''){
                                            document.getElementById('c3').style.display = 'none';
                                            document.getElementById('d3').style.display = 'block';
                                        }else{
                                            switch(x6){
                                                case 'Comediante':
                                                        document.getElementById('d3').style.display = 'none';
                                                        document.getElementById('p13').style.display = 'block';
                                                    break;
                                                case 'Youtuber':
                                                        document.getElementById('d3').style.display = 'none';
                                                        document.getElementById('p14').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                            }
                        }
                    break;
                case 'Meme':
                        document.getElementById('b2').style.display = 'none';
                        document.getElementById('p15').style.display = 'block';
                    break;
                case 'Historia':
                        if(x5 == ''){
                            document.getElementById('b2').style.display = 'none';
                            document.getElementById('c4').style.display = 'block';
                        }else{
                            switch(x5){
                                case 'Castaño':
                                        document.getElementById('c4').style.display = 'none';
                                        document.getElementById('p16').style.display = 'block';
                                    break;
                                case 'Negro':
                                        if(x6 == ''){
                                            document.getElementById('c4').style.display = 'none';
                                            document.getElementById('d4').style.display = 'block';
                                        }else{
                                            switch(x6){
                                                case 'General':
                                                        if(x7 == ''){
                                                            document.getElementById('d4').style.display = 'none';
                                                            document.getElementById('e1').style.display = 'block';
                                                        }else{
                                                            switch(x7){
                                                                case 'Frances':
                                                                        document.getElementById('e1').style.display = 'none';
                                                                        document.getElementById('p19').style.display = 'block';
                                                                    break;
                                                                case 'Austriaco':
                                                                        document.getElementById('e1').style.display = 'none';
                                                                        document.getElementById('p20').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Soldado':
                                                        document.getElementById('d4').style.display = 'none';
                                                        document.getElementById('p18').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                                case 'Blanco':
                                        document.getElementById('c4').style.display = 'none';
                                        document.getElementById('p17').style.display = 'block';
                                    break;
                            }
                        }
                    break;
            }
        }
    }else if(x == "no"){
        this.a = x;
        if(x1 == ''){
            document.getElementById('a1').style.display = 'none';
            document.getElementById('b1').style.display = 'block'
        }else{
            switch(x1){
                case 'Mascota':
                        document.getElementById('b1').style.display = 'none';
                        document.getElementById('p21').style.display = 'block';
                    break;
                case 'Videojuegos':
                        if(x3 == ''){
                            document.getElementById('b1').style.display = 'none';
                            document.getElementById('c5').style.display = 'block';
                        }else{
                            switch(x3){
                                case 'Humano':
                                        if(x5 == ''){
                                            document.getElementById('c5').style.display = 'none';
                                            document.getElementById('d5').style.display = 'block';                 
                                        }else{
                                            switch(x5){
                                                case 'Castaño':
                                                        if(x6 == ''){
                                                            document.getElementById('d5').style.display = 'none';
                                                            document.getElementById('e2').style.display = 'block';
                                                        }else{
                                                            switch(x6){
                                                                case 'Asesino':
                                                                        document.getElementById('e2').style.display = 'none';
                                                                        document.getElementById('p24').style.display = 'block';
                                                                    break;
                                                                case 'Plomero':
                                                                        document.getElementById('e2').style.display = 'none';
                                                                        document.getElementById('p25').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Negro':
                                                        if(x6 == ''){
                                                            document.getElementById('d5').style.display = 'none';
                                                            document.getElementById('e3').style.display = 'block';
                                                        }else{
                                                            switch(x6){
                                                                case 'Plomero':
                                                                        document.getElementById('e3').style.display = 'none';
                                                                        document.getElementById('p26').style.display = 'block';
                                                                    break;
                                                                case 'Soldado':
                                                                        document.getElementById('e3').style.display = 'none';
                                                                        document.getElementById('p27').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Rubio':
                                                        document.getElementById('d5').style.display = 'none';
                                                        document.getElementById('p23').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                                case 'Semi-dios':
                                        document.getElementById('c5').style.display = 'none';
                                        document.getElementById('p22').style.display = 'block';
                                    break;
                                case 'Animal':
                                        if(x4 == ''){
                                            document.getElementById('c5').style.display = 'none';
                                            document.getElementById('d6').style.display = 'block';
                                        }else{
                                            switch(x4){
                                                case 'Si':
                                                        document.getElementById('d6').style.display = 'none';
                                                        document.getElementById('p28').style.display = 'block';
                                                    break;
                                                case 'No':
                                                        if(x6 == ''){
                                                            document.getElementById('d6').style.display = 'none';
                                                            document.getElementById('e5').style.display = 'block';
                                                        }else{
                                                            switch(x6){
                                                                case 'Ayudante':
                                                                        document.getElementById('e5').style.display = 'none';
                                                                        document.getElementById('p29').style.display = 'block';
                                                                    break;
                                                                case 'Codigo':
                                                                        document.getElementById('e5').style.display = 'none';
                                                                        document.getElementById('p30').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                            }
                                        }
                                    break;
                            }
                        }
                    break;
                case 'Anime':
                        if(x3 == ''){
                            document.getElementById('b1').style.display = 'none';
                            document.getElementById('c6').style.display = 'block';     
                        }else{
                            switch(x3){
                                case 'Humano':
                                        if( x5 == ''){
                                            document.getElementById('c6').style.display = 'none';
                                            document.getElementById('d7').style.display = 'block';
                                        }else{
                                            switch(x5){
                                                case 'Negro':
                                                        if(x6 == ''){
                                                            document.getElementById('d7').style.display = 'none';
                                                            document.getElementById('e6').style.display = 'block';
                                                        }else{
                                                            switch(x6){
                                                                case 'Caballero':
                                                                        document.getElementById('e6').style.display = 'none';
                                                                        document.getElementById('p32').style.display = 'block';
                                                                    break;
                                                                case 'Pirata':
                                                                        document.getElementById('e6').style.display = 'none';
                                                                        document.getElementById('p33').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Rubio':
                                                        document.getElementById('d7').style.display = 'none';
                                                        document.getElementById('p31').style.display = 'block';  
                                                    break;
                                            }
                                        }
                                    break;
                                case 'Saiyajin':
                                        if(x6 == ''){
                                            document.getElementById('c6').style.display = 'none';
                                            document.getElementById('d8').style.display = 'block';
                                        }else{
                                            switch(x6){
                                                case 'Erudito':
                                                        document.getElementById('d8').style.display = 'none';
                                                        document.getElementById('p34').style.display = 'block';
                                                    break;
                                                case 'Luchador':
                                                        document.getElementById('d8').style.display = 'none';
                                                        document.getElementById('p35').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                            }
                        }
                    break;
                case 'Pelicula':
                        if(x2 == ''){
                            document.getElementById('b1').style.display = 'none';
                            document.getElementById('c7').style.display = 'block';
                        }else{
                            switch(x2){
                                case 'M':
                                        document.getElementById('c7').style.display = 'none';
                                        document.getElementById('p36').style.display = 'block';
                                    break;
                                case 'H':
                                        if(x3 == ''){
                                            document.getElementById('c7').style.display = 'none';
                                            document.getElementById('d9').style.display = 'block';
                                        }else{
                                            switch(x3){
                                                case 'Humano':
                                                        if(x5 == ''){
                                                            document.getElementById('d9').style.display = 'none';
                                                            document.getElementById('e7').style.display = 'block';
                                                        }else{
                                                            switch(x5){
                                                                case 'Negro':
                                                                        document.getElementById('e7').style.display = 'none';
                                                                        document.getElementById('p38').style.display = 'block';
                                                                    break;
                                                                case 'Castaño':
                                                                        if(x6 == ''){
                                                                            document.getElementById('e7').style.display = 'none';
                                                                            document.getElementById('f1').style.display = 'block';
                                                                        }else{
                                                                            switch(x6){
                                                                                case 'Cantante':
                                                                                        document.getElementById('f1').style.display = 'none';
                                                                                        document.getElementById('p39').style.display = 'block';
                                                                                    break;
                                                                                case 'Estudiante':
                                                                                        document.getElementById('f1').style.display = 'none';
                                                                                        document.getElementById('p40').style.display = 'block';
                                                                                    break;
                                                                            }
                                                                        }
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Animal':
                                                        document.getElementById('d9').style.display = 'none';
                                                        document.getElementById('p37').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                            }
                        }
                    break;
                case 'Animacion':
                        if(x2 == ''){
                            document.getElementById('b1').style.display = 'none';
                            document.getElementById('c8').style.display = 'block';
                        }else{
                            switch(x2){
                                case 'M':
                                        document.getElementById('c8').style.display = 'none';
                                        document.getElementById('p41').style.display = 'block';  
                                    break;
                                case 'H':
                                        if(x3 == ''){
                                            document.getElementById('c8').style.display = 'none';
                                            document.getElementById('d10').style.display = 'block';
                                        }else{
                                            switch(x3){
                                                case 'Humano':
                                                        if(x5 == ''){
                                                            document.getElementById('d10').style.display = 'none';
                                                            document.getElementById('e8').style.display = 'block';  
                                                        }else{
                                                            switch(x5){
                                                                case 'Castaño':
                                                                        document.getElementById('e8').style.display = 'none';
                                                                        document.getElementById('p44').style.display = 'block';  
                                                                    break;
                                                                case 'Negro':
                                                                        document.getElementById('e8').style.display = 'none';
                                                                        document.getElementById('p45').style.display = 'block';  
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Monstruo':
                                                        document.getElementById('d10').style.display = 'none';
                                                        document.getElementById('p46').style.display = 'block';
                                                    break;
                                                case 'Animal':
                                                        if(x6 == ''){
                                                            document.getElementById('d10').style.display = 'none';
                                                            document.getElementById('e9').style.display = 'block';
                                                        }else{
                                                            switch(x6){
                                                                case 'Asesino':
                                                                        document.getElementById('e9').style.display = 'none';
                                                                        document.getElementById('p47').style.display = 'block';
                                                                    break;
                                                                case 'Cajero':
                                                                        document.getElementById('e9').style.display = 'none';
                                                                        document.getElementById('p48').style.display = 'block';
                                                                    break;
                                                            }
                                                        }
                                                    break;
                                                case 'Hada':
                                                        document.getElementById('d10').style.display = 'none';
                                                        document.getElementById('p43').style.display = 'block';
                                                    break;
                                                case 'Mutante':
                                                        document.getElementById('d10').style.display = 'none';
                                                        document.getElementById('p42').style.display = 'block';
                                                    break;
                                            }
                                        }
                                    break;
                            }
                        }
                    break;
                case 'Folcore':
                        if(x5 == ''){
                            document.getElementById('b1').style.display = 'none';
                            document.getElementById('c9').style.display = 'block';
                        }else{
                            switch(x5){
                                case 'Negro':
                                        document.getElementById('c9').style.display = 'none';
                                        document.getElementById('p49').style.display = 'block';
                                    break;
                                case 'Rubio':
                                        document.getElementById('c9').style.display = 'none';
                                        document.getElementById('p50').style.display = 'block';
                                    break;
                            }
                        }
                    break;
                case 'Manga':
                        document.getElementById('b1').style.display = 'none';
                        document.getElementById('p51').style.display = 'block';
                    break;
                case 'Meme':
                        document.getElementById('b1').style.display = 'none';
                        document.getElementById('p52').style.display = 'block';
                    break;
            }
        }
    }
}
//-------------------------------------------------------------
